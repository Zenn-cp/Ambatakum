#include <stdio.h>

int main(){
    int NIM;
    int kodeSoal;
    char kodeKelas;
    float alas;
    float tinggi;

    printf("====DATA DIRI====");
    printf("\nMasukkan NIM anda: ");
    scanf("%d", &NIM);
    kodeSoal = 2 - (NIM % 2);
    printf("Masukkan kode kelas DDP anda: ");
    scanf(" %c", &kodeKelas);

    printf("=====DATA DIRI=====");
    printf("\nNim : %d", NIM);
    printf("\nKode kelas DDP : %c", kodeKelas);
    printf("\nKode soal : %d\n", kodeSoal);

    printf("====Bangun Datar====");
    printf("\nMasukkan Alas : ");
    scanf("%f", &alas);
    printf("Masukkan Tinggi : ");
    scanf("%f", &tinggi);

    printf("====Bangun Datar====");
    printf("\nLuas Jajar Genjang  : %.1f", alas*tinggi);
    printf("\nLuas Segitiga : %.2f", 0.5*alas*tinggi);


    return 0; 
}